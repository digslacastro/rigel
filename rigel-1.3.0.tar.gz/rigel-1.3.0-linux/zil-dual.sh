#!/bin/sh

# replace the wallet addresses with your own

# etc + zil
./rigel -a etchash+zil \
    -o [1]stratum+tcp://us1-etc.ethermine.org:4444 -u [1]YOUR_ETC_WALLET \
    -o [2]zmp://zil.flexpool.io                    -u [2]YOUR_ZIL_WALLET \
    -w my_rig --log-file logs/miner.log

# ethw + zil
#./rigel -a ethash+zil \
#   -o [1]stratum+ssl://ethw.2miners.com:12020 -u [1]YOUR_ETHW_WALLET \
#   -o [2]zmp://zil.flexpool.io                -u [2]YOUR_ZIL_WALLET \
#   -w my_rig --log-file logs/miner.log

# kas + zil
#./rigel -a kheavyhash+zil \
#   -o [1]stratum+tcp://pool.woolypooly.com:3112 -u [1]YOUR_KAS_WALLET \
#   -o [2]zmp+tcp://us1-zil.shardpool.io:3333    -u [2]YOUR_ZIL_WALLET \
#   -w my_rig --log-file logs/miner.log

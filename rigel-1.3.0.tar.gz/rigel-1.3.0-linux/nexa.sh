#!/bin/sh

# replace the wallet addresses with your own

# mine to woolypooly
./rigel -a nexapow -o stratum+tcp://pool.woolypooly.com:3124 -u YOUR_NEXA_WALLET -w my_rig --log-file logs/miner.log

# mine to rplant
#./rigel -a nexapow -o stratum+tcp://stratum-eu.rplant.xyz:7092 -u YOUR_NEXA_WALLET -w my_rig --log-file logs/miner.log
